#! /bin/bash

bec1=0
bec2=0
n=-1

IFS=" "

echo "$(grep -o -E '\w+' $1 | sort -n | uniq -c | tr -s ' ' | awk '{print $2" "$1}' | sort -t " " -k2,2rn -k1,1 )" > fisier

if test "$2" = "--count" -o "$4" = "--count" -o "$6" = "--count" ; then
	if test "$2" = "--count"; then
		n=$3
	fi
	if test "$4" = "--count"; then
                n=$5	
	fi
	if test "$6" = "--count"; then
                n=$7
        fi
fi

if test "$2" = ""; then
	n=15
fi	

if test "$2" = "--lines" -o "$4" = "--lines" -o "$6" = "--lines"; then	
	if test "$2" = "--lines"; then
                a=$3
        fi
        if test "$4" = "--lines"; then
                a=$5
        fi
        if test "$6" = "--lines"; then
                a=$7
        fi
#	echo "$(head -$a $1 | grep -o -E '\w+' | sort -n | uniq -c | tr -s ' ' | awk '{print $2" "$1}' | sort -t " " -k2,2rn -k1,1 )" > fisier
	bec1=1
fi

if test "$2" = "--over" -o "$4" = "--over" -o "$6" = "--over"; then
	if test "$2" = "--over"; then
                b=$3
        fi
        if test "$4" = "--over"; then
                b=$5
        fi
        if test "$6" = "--over"; then
                b=$7
        fi	
	bec2=1	
fi
	

	 if test "$bec1" -eq 1; then
		echo "$(head -$a $1 | grep -o -E '\w+' | sort -n | uniq -c | tr -s ' ' | awk '{print $2" "$1}' | sort -t " " -k2,2rn -k1,1 )" > fisier
         fi



	while read file nr; do

			if test "$n" -ge 1 -o "$bec1" -eq 1 -o "$bec2" -eq 1 ; then

		#		if test "$bec1" -eq 1; then
		#			echo "$(head -$a $1 | grep -o -E '\w+' | sort -n | uniq -c | tr -s ' ' | awk '{print $2" "$1}' | sort -t " " -k2,2rn -k1,1 )" > fisier
		#		fi

				if test "$bec2" -eq 1; then

		                        if test $nr -ge $b ; then
                	                	echo "$file $nr"
					fi
				else	
                	       		echo "$file $nr"
				fi
                	       	
				if test "$n" -ne 0 ; then
                                        n=$((n-1))
                                fi
				
				if test "$n" -eq 0 ; then
					break;
				fi
 	       			
			fi 

	done < fisier

