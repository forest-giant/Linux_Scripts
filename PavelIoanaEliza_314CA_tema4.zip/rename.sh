#!/bin/bash

if test "$2" = "" ; then
	echo "Scriptul trebuie sa primeasca minim 2 parametri."; else
	
	# IN FISIER AM O LISTA CU TOATE ELEMENTELE DIN DIRECTOR SI IN NUMAR PUN NUMARUL DE FISIERE
	ls -1 $3 > .fisier
	touch numar
	mkdir folder

	cat .fisier | wc -l > numar
	# AICI PUN NUMARUL DE CIFRE DE LA FISIERE(ADICA DACA AM 123 DE FISIERE, A=3)
	a=$(cat numar | wc -L)
	# VERIFIC DACA AM ARGUMENTUL 3 
	if test "$3" = ""; then
		c=$(echo ""); else
		c=$(echo "/")
	fi
	
	i=1
	# COPIEZ CONTINUTUL DIRECTORULUI IN FOLDER
	while read file; do
		mv $3$c$file folder
	done < .fisier
	
	while read file; do
	# B RETINE NUMARUL DE CIFRE ALE LUI I
		b=${#i}
	# CONDITIA ASTA IMI ZICE DACA TREBUIE SAU NU SA PUN VREUN 0 IN FATA CIFREI(CONTORULUI)
		if test "$a" -eq "1"; then
			# IN NUME PUN CUM URMEAZA SA SE NUMEASCA, SI IN FISIER PUN CUM S-A NUMIT
			nume=$(echo "$3$c$1$i.$2")
			fisier=$(echo "folder/$file")
			mv $fisier $nume; else

			nume=$(echo "$3$c$1$(for j in $(seq 1 $(($a-$b))); do printf "0"; done)$i.$2")
			fisier=$(echo "folder/$file")
			mv $fisier $nume
		fi
		i=$((i+1))
	done < .fisier
	rm -R folder
#	rm fisier
	rm numar
fi


		
