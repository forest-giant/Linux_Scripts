#!/bin/bash

bold1=0
bold2=0

if test "$1" = ""; then
	echo "Scriptul trebuie sa primeasca calea catre un fisier."; else

	a=$( [ -f $1 ] && echo "1" || echo "2") 
	if test "$a" = 2; then
		echo "Fisierul $1 nu exista.";else

	cat $1 | tr -s ' ' '\n' > text
	i=0
	bold=0
	while read file; do
		a=$(echo "$file" | grep -wo '[/*/*]' | wc -l)
		if test "$a" -eq 1;then
			if test "$i" -eq 0; then
				i=1;else
					bold=$((bold+1))
					i=0
			fi
		fi

		if test "$i" -eq 1; then
			bold=$((bold+1))
		fi

		if test "$a" -eq 2; then
			bold=$((bold+1))
		fi
	done < text
	
	i=0
	while read file; do
                a=$(echo "$file" | grep -o '__' | wc -l)
                if test "$a" -eq 1;then
                        if test "$i" -eq 0; then
                                i=1;else
                                        bold=$((bold+1))
                                        i=0
                        fi
                fi

                if test "$i" -eq 1; then
                        bold=$((bold+1))
                fi

                if test "$a" -eq 2; then
                        bold=$((bold+1))
                fi
        done < text

	i=0
	italic=0
        while read file; do
                a=$(echo "$file" | grep -o '_' | wc -l)
		b=$(echo "$file" | grep -o '__' | wc -l)
		c=$((a-2*b))
                if test "$c" -eq 1;then
                        if test "$i" -eq 0; then
                                i=1;else
                                        italic=$((italic+1))
                                        i=0
                        fi
                fi

                if test "$i" -eq 1; then
                        italic=$((italic+1))
                fi

                if test "$c" -eq 2; then
                        italic=$((italic+1))
                fi
        done < text

	
	i=0
	while read file; do
                a=$(echo "$file" | grep -o '*' | wc -l)
                b=$(echo "$file" | grep -wo '[/*/*]' | wc -l)
                c=$((a-2*b))
                if test "$c" -eq 1;then
                        if test "$i" -eq 0; then
                                i=1;else
                                        italic=$((italic+1))
                                        i=0
                        fi
                fi

                if test "$i" -eq 1; then
                        italic=$((italic+1))
                fi

                if test "$c" -eq 2; then
                        italic=$((italic+1))
                fi
        done < text

	bec1=0
	bec2=0	
	b_i=0
	i=0
	j=0
#	b_i1=0
	e=$(echo text | head -1 | cut -c1-2)
                f=$(echo "**")
                if [[ $e = *"$f"* ]]; then
		bec1=1
        while read file; do
#		e=$(echo $file | cut -c1-2)
#		f=$(echo "**")	
#		if [[ $e = *"$f"* ]]; then

                a=$(echo "$file" | grep -o '_' | wc -l)
                b=$(echo "$file" | grep -o '__' | wc -l)
                c=$((a-2*b))
		d=$(echo "$file" | grep -wo '[/*/*]' | wc -l)

                if test "$d" -eq 1 -a "$c" -eq 0 ;then
                        if test "$i" -eq 0; then
                                i=1
				continue;else
                                i=0
			#	j=0
                        fi
                fi
		
		if test "$d" -eq 1 -a "$c" -eq 1 ;then
                        if test "$i" -eq 0; then
                                i=1
				j=1;else
				b_i=$((b_i + 1))
                                i=0
                                j=0
				continue
                        fi
                fi

		if test "$d" -eq 1 -a "$c" -eq 2 ;then
                        if test "$i" -eq 0; then
                                i=1;else
                               		i=0
                               		j=0
                        fi
			b_i=$((b_i + 1))
			continue
                fi
		
		if test "$c" -eq 1 -a $i -eq 1;then
			if test $j -eq 0; then
				j=1;else
					j=0
					b_i=$((b_i + 1))
					continue
			fi
		fi

		if test "$c" -eq 2 -a "$i" -eq 1; then
			b_i=$((b_i + 1))
			continue
		fi

		if test "$i" -eq 1 -a "$j" -eq 1; then
			b_i=$((b_i + 1))
			continue
		fi

		if test "$c" -eq 2 -a "$d" -eq 2; then
			b_i=$((b_i + 1))
			continue
		fi
		#fi
        done < text
	fi	
#	echo "$b_i"

	i=0
	j=0	
#	b_i2=0

	 e=$(echo text | head -1 | cut -c1-2)
                f=$(echo "__")
                if [[ $e = *"$f"* ]]; then

		bec2=1
	while read file;do
#		e=$(echo $file | cut -c1-2)
#		f=$(echo "__")
#		if [[ $e = *"$f"* ]]; then
	
		a=$(echo $file | grep -o '*' | wc -l)
		b=$(echo $file | grep -wo '[/*/*]' | wc -l)
		c=$((a-2*b))
		d=$(echo $file | grep -o '__' | wc -l)

		if test "$d" -eq 1 -a "$c" -eq 0; then
			if test "$i" -eq 0; then
                                i=1;else
                               		 i=0
                              	#	 j=0
                        fi
		fi

		if test "$d" -eq 1 -a "$c" -eq 1 ;then
                        if test "$i" -eq 0; then
                                i=1
                                j=1;else
                                b_i=$((b_i + 1))
                                i=0
                                j=0
				continue
                        fi
                fi

                if test "$d" -eq 1 -a "$c" -eq 2 ;then
                        if test "$i" -eq 0; then
                                i=1;else
                                        i=0
                                        j=0
                        fi
                        b_i=$((b_i + 1))
			continue
                fi

                if test "$c" -eq 1 -a $i -eq 1;then
                        if test $j -eq 0; then
                                j=1;else
                                        j=0
                                        b_i=$((b_i + 1))
					continue
                        fi
                fi

                if test "$c" -eq 2 -a "$i" -eq 1; then
                         b_i=$((b_i + 1))
			continue
                fi

                if test "$i" -eq 1 -a "$j" -eq 1; then
                         b_i=$((b_i + 1))
			continue
                fi

                if test "$c" -eq 2 -a "$d" -eq 2; then
                        b_i=$((b_i + 1))
			continue
                fi
	#	fi
       	done < text
	fi		
#	echo "$b_i"
	
	i=0
	j=0
#	b_i3=0
	
	if test "$bec1" -eq 0; then
	while read file; do
		a=$(echo $file | grep -o '_' | wc -l)
		b=$(echo $file | grep -o '__' | wc -l)
		d=$((a-2*b))
		c=$(echo $file | grep -wo '[/*/*]' | wc -l)

		if test "$d" -eq 1 -a "$c" -eq 0 ;then
                        if test "$i" -eq 0; then
                                i=1
				continue;else
                                	i=0
                                #	j=0
                        fi
                fi
 		

		if test "$d" -eq 1 -a "$c" -eq 1 ;then
                        if test "$i" -eq 0; then
                                i=1
                                j=1;else
                                b_i=$((b_i + 1))
                                i=0
                                j=0
				continue
                        fi
                fi

                if test "$d" -eq 1 -a "$c" -eq 2 ;then
                        if test "$i" -eq 0; then
                                i=1;else
                                        i=0
                                        j=0
                        fi
                        b_i=$((b_i + 1))
			continue
                fi

                if test "$c" -eq 1 -a $i -eq 1;then
                        if test $j -eq 0; then
                                j=1;else
                                        j=0
                                        b_i=$((b_i + 1))
					continue
                        fi
                fi

                if test "$c" -eq 2 -a "$i" -eq 1; then
                         b_i=$((b_i + 1))
			continue
                fi

                if test "$i" -eq 1 -a "$j" -eq 1; then
                         b_i=$((b_i + 1))
			continue
                fi

                if test "$c" -eq 2 -a "$d" -eq 2; then
                        b_i=$((b_i + 1))
			continue
                fi
        done < text
	fi

#	echo "$b_i"

	i=0
	j=0
#	b_i4=0
	if test "$bec2" -eq 0; then
	while read file; do
		a=$(echo "$file" | grep -o '*'| wc -l)
		b=$(echo "$file" | grep -ow '[/*/*]'| wc -l)
		d=$((a-2*b))
		c=$(echo "$file" | grep -o '__'| wc -l)
	
		if test "$d" -eq 1 -a "$c" -eq 0 ;then
                        if test "$i" -eq 0; then
                                i=1
                                continue;else
                                b_i=$((b_i + 1))
                                i=0
                               # j=0
                        fi
                fi
	
		if test "$d" -eq 1 -a "$c" -eq 1 ;then
                        if test "$i" -eq 0; then
                                i=1
                                j=1;else
                                b_i=$((b_i + 1))
                                i=0
                                j=0
				continue
                        fi
                fi

                if test "$d" -eq 1 -a "$c" -eq 2 ;then
                        if test "$i" -eq 0; then
                                i=1;else
                                        i=0
                                        j=0
                        fi
                        b_i=$((b_i + 1))
			continue
                fi

                if test "$c" -eq 1 -a $i -eq 1;then
                        if test $j -eq 0; then
                                j=1;else
                                        j=0
                                        b_i=$((b_i + 1))
					continue
                        fi
                fi

                if test "$c" -eq 2 -a "$i" -eq 1; then
                         b_i=$((b_i + 1))
			continue
                fi

                if test "$i" -eq 1 -a "$j" -eq 1; then
                         b_i=$((b_i + 1))
			continue
                fi

                if test "$c" -eq 2 -a "$d" -eq 2; then
                        b_i=$((b_i + 1))
			continue
                fi
	done <text 
	fi

#	echo "$b_i"
	
#	if test "$b_i2" -gt "$b_i4"; then
#		b_i=$((b_i + b_i2));else
#		b_i=$((b_i + b_i4))
#	fi

#	if test "$b_i1" -gt "$b_i3"; then
 #               b_i=$((b_i + b_i1));else
 #               b_i=$((b_i + b_i3))
#	fi


	echo "Cuvinte bold: $((bold))" 
	echo "Cuvinte italice: $((italic))"
	echo "Cuvinte si bold si italice: $((b_i))"

	fi
fi
	

