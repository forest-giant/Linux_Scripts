#!/bin/bash

if test "$1" = ""; then
	echo "Scriptul trebuie sa primeasca un fisier sau un pattern.";else


if test "$1" != "--pattern"; then
	a=$([ -f $1 ] && echo "1" || echo "2")
	if test "$a" = "2"; then
		echo "Fisierul $1 nu exista."
	fi
	if test "$a" = "1"; then
		data_acces=$(stat $1 | tail -4 | head -1 | cut -d " " -f2 | sed 's/-/ /g' | awk '{print $3"/"$2"/"$1}')
		time_acces=$(stat $1 | tail -4 | head -1 | cut -d " " -f3 | cut -d ":" -f1,2)
		data_mod=$(stat $1 | tail -3 | head -1 | cut -d " " -f2 | sed 's/-/ /g' | awk '{print $3"/"$2"/"$1}')
		time_mod=$(stat $1 | tail -3 | head -1 | cut -d " " -f3 | cut -d ":" -f1,2)
		echo "Fisierul $1 a fost modificat pe $data_mod la $time_mod si accesat pe $data_acces la $time_acces."

	fi
fi

if test "$1" = "--pattern"; then
	if test "$2" = ""; then
		echo "Optiunea --pattern trebuie urmata de un pattern.";else
		
		touch .fisier1
		sudo chmod 777 .fisier1

		
		b=$2
		a=$(echo "$2" | grep -o '?' | wc -l)
		if test "$a" -ne 0; then
			b=$(echo "$b" | sed -e 's/?/\\\?/g')
		fi

		a=$(echo "$2" | grep -o '+' | wc -l)
                if test "$a" -ne 0; then
                        b=$(echo "$b" | sed -e 's/+/\\\+/g')

		fi

		a=$(echo "$2" | grep -o '{' | wc -l)
                if test "$a" -ne 0; then
                        b=$(echo "$b" | sed -e 's/[{]/\{/g')

                fi

		a=$(echo "$2" | grep -o '}' | wc -l)
                if test "$a" -ne 0; then
                        b=$(echo "$b" | sed -e 's/[}]/\}/g')

                fi


		a=$(echo "$2" | grep -o '|' | wc -l)
                if test "$a" -ne 0; then
                        b=$(echo "$b" | sed -e 's/|/\\\|/g')
 
                fi

		a=$(echo "$2" | grep -o '(' | wc -l)
                if test "$a" -ne 0; then
                        b=$(echo "$b" | sed -e 's/(/\\\(/g')

                fi

		a=$(echo "$2" | grep -o ')' | wc -l)
                if test "$a" -ne 0; then
                        b=$(echo "$2" | sed -e 's/)/\\\)/g')

                fi
	
		ls -u1 | grep "^$b$" > .fisier1

		touch .fisier2
		sudo chmod 777 .fisier2
		
		while read file; do
			data_acces=$(stat $file | tail -4 | head -1 | cut -d " " -f2 | sed 's/-/ /g' | awk '{print $3"/"$2"/"$1}')
	                time_acces=$(stat $file | tail -4 | head -1 | cut -d " " -f3 | cut -d ":" -f1,2)
        	        data_mod=$(stat $file | tail -3 | head -1 | cut -d " " -f2 | sed 's/-/ /g' | awk '{print $3"/"$2"/"$1}')
               		time_mod=$(stat $file | tail -3 | head -1 | cut -d " " -f3 | cut -d ":" -f1,2)
                	echo "Fisierul $file a fost modificat pe $data_mod la $time_mod si accesat pe $data_acces la $time_acces." >> .fisier2 
		done < .fisier1

		cat .fisier2

		rm .fisier2
		rm .fisier1
	fi 
fi
fi
